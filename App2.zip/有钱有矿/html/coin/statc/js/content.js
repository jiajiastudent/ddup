var swiper = new Swiper('.swiper-container',{
  pagination: '.swiper-pagination',
  paginationType : 'custom',
  loop : true,
  loopedSlides : 1,
  paginationCustomRender: function (swiper, current, total) {
       return '<span>'+current+'</span>' + '/' + '<span>'+total+'</span>';
   }
});
$api.addEvt($api.dom('.specif'), 'click', function () {
  api.openFrame({
      bgColor : 'rgba(0,0,0,0.6)',
      name : 'speciframe',
      url : 'speciframe.html',
      bounces : false,
      rect : {
            x : 0,
            y : 0,
            w : api.winWidth,
            h : api.winHeight
        }
   });
});
$api.addEvt($api.dom('.discount-gz'), 'click', function () {
  api.openFrame({
      bgColor : 'rgba(0,0,0,0.6)',
      name : 'shareframe',
      url : 'shareframe.html',
      bounces : false,
      rect : {
            x : 0,
            y : 0,
            w : api.winWidth,
            h : api.winHeight
        }
   });
});
