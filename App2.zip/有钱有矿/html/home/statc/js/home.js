apiready = function () {

}
var swiper = new Swiper('.swiper-container', {
    slidesPerView: 2.5,
    spaceBetween: 6
});
  // $(document).scroll(function() {
  //        var scroH = $('body').scrollTop();  //滚动高度
  //       // var viewH = $(window).height();  //可见高度
  //       // var contentH = $(document).height();  //内容高度
  //       if (scroH > 6) {
  //         $('header').css('height','22px');
  //         $('.content').css('marginTop','22px')
  //         $('.title').css('fontSize','14px')
  //       }else {
  //         $('header').css('height','40px');
  //         $('.content').css('marginTop','40px');
  //         $('.title').css('fontSize','20px')
  //       }
  //     });
