push_navigator = function (name,url) {
  api.openWin({
      name: name,
      url: url,
      pageParam: {
        name: name
      }
  });
}
back_navigator = function (name) {
  api.closeWin({
    name: name
  });
}
