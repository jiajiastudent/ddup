/**
 * Created by mmcai on 2015/6/12.
 */

//字体自适应,字体单位rem
(function (win, doc) {
    var styleElem = doc.createElement("style");
    styleElem.setAttribute("id", "J_style");
    doc.head.appendChild(styleElem);

    var evt = "onorientationchange" in win ? "orientationchange" : "resize";

    function b() {
        var
            e,
            b = doc.getElementById("J_style"),
            c = doc.documentElement.clientWidth || doc.body.clientWidth,
            h = doc.documentElement.clientHeight || doc.body.clientHeight,
            d = 1;

        d = c / 640,
            e = 100 * d,
            b.innerHTML = "html{font-size:" + e + "px;}",
            a = d;


        if (!wrap) {
            var cont = doc.createElement("div");
            cont.setAttribute("id", "J_context");
            cont.style.width = "6.4rem";
            doc.body.appendChild(cont);
        }

        var wrap = doc.getElementById('J_context');
        var width = wrap.clientWidth;
        if (width != c) {
            e = c * c / width / 6.4;
            document.documentElement.style.fontSize = e + "px";
        }

        // window._z = d;
    }

    var timer = null;
    win.addEventListener(evt, function () {
        if (timer != null) clearTimeout(timer);
        timer = setTimeout(b, 300);
    }, false);


    // 初始化
    doc.addEventListener("DOMContentLoaded", b, false);
})(window, document);


