var urls = {
  domain:"http://5c45c0c43858aa001418c4a7.mockapi.io/",
  IndexNews:"indexNews",
}
