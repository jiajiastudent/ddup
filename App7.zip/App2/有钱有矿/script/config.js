var config={
	//ServerIP:"http://192.168.43.107:6004"
	ServerIP:'http://mng.mizuda.xin'
//	ServerIP:'http://121.41.81.89:6004'
//	ServerIP:'http://192.168.0.193:6004'
//	ServerIP:'http://192.168.43.207:6004'
//	ServerIP:'http://192.168.137.1:6004'0
	//ServerIP:'http://192.168.0.136:6004'
	// ServerIP:'http://172.20.10.3:6004'
	//ServerIP:'http://192.168.1.108:6004'
	//ServerIP:'http://192.168.1.199:6004'
//	ServerIP:'http://192.168.1.162:6004'

}

var config2={
	ServerIP:'http://121.41.81.89:9002'
//	ServerIP:'http://192.168.43.207:6003'
}

var config3={
	ServerIP:'http://door-nth.mizuda.xin:9008'
//	ServerIP:'http://192.168.43.207:6003'
}

var config4={
	ServerIP:'http://xunjian.mizuda.xin'
//	ServerIP:'http://192.168.43.207:6003'
}
var TEST=false
var user={};
var ak='MbjbTZdPlGdoq63HIdOy69CdF47s0uUP'//for android  MbjbTZdPlGdoq63HIdOy69CdF47s0uUP
var ak1='sbdosxkGctdl2G3aq1GIno7XwlXbNjty'//for ios
var mcode='43:90:28:59:AC:17:C9:1D:6F:44:2B:A7:0C:74:39:B9:17:EC:D9:EA;com.fullrich.wannavehicle'//for android
var mcode1='com.fullrich.wannagps'//for ios
var routeid=null;
var truckroute=null;
var Url={
	//员工扫描二维码登录
	qrcodelogin:config.ServerIP+'/qrcodelogin/submit-login/',	//employee_ref/loginID
	//信息查询相关
	getvehiclemonitor:config.ServerIP+'/truckmng_baidu/get-vehicle-monitor',
	getallroute:config.ServerIP+'/truckmng/get-all-routelist',

	//私车公用相关
	applyprice:config.ServerIP+'/truckmng/apply-price/',	//:id
	getapplyroute:config.ServerIP+'/truckmng/get-apply-route/',	//:companyid（不用）
	auditprice:config.ServerIP+'/truckmng/audit-price/',	//:id/:audit_flag
	getapplyrouteauth:config.ServerIP+'/truckmng/get-apply-route-auth/',	//:tel（新）

	//登录注册相关
	//register:config.ServerIP+'/employee/tel/new-register',
	register:config.ServerIP+'/employee/tel/register',
	login:config.ServerIP+'/employee/tel/login',
	regnum:config.ServerIP+'/employee/tel/send-register-code/',

	//签到相关
	checkinfo:config.ServerIP+'/employee/get-person-checkinfo/',//:tel/:day
	checkin:config.ServerIP+'/employee/tel/checkin/',//:tel/:gpsstr/:address'
	checkout:config.ServerIP+'/employee/tel/checkout/',//:tel/:gpsstr/:address'
	checkvalid:config.ServerIP+'/employee/tel/checkvalid/',//:tel/:gpsstr'
	checkperiod:config.ServerIP+'/employee/get-person-period-checkinfo/',//:tel/:startday/:endday'
	getwork:config.ServerIP +'/system/company/getworkschedule-isworkday/',	//:year/:month/:day(查询今天是否是工作日)
	getcompany:config.ServerIP+'/system/company/getinfobyid/',	//company_ref

	startroute:config.ServerIP+'/truckmng_baidu/start-travelroute/',//:employeeid/:truckid'
	findlastroute:config.ServerIP+'/truckmng/find-lastroute/',	//:employeeid
	endroute:config.ServerIP+'/truckmng_baidu/stop-travelroute/',//:id/:distance'
	setroutenf:config.ServerIP+'/truckmng/setlocpt-noflush/',//:routeid/:lng/:lat'
	setroutewf:config.ServerIP+'/truckmng/setlocpt-withflush/',//:routeid/:lng/:lat'
	getroutelist:config.ServerIP+'/truckmng_baidu/route-list/',//:employeeid'
	getroutebyid:config.ServerIP+'/truckmng/get-route-by-id/',//:routeid'
	overtimework:config.ServerIP+'/employee/tel/overtimework/',//tel
	addpoint:'http://yingyan.baidu.com/api/v3/track/addpoint',//
	addpoints:'http://yingyan.baidu.com/api/v3/track/addpoints',
	gettrack:config.ServerIP+'/truckmng_baidu/get-route/',
	leave:config.ServerIP+'/employee/tel/leave/',//:tel/:day
	latereason:config.ServerIP+'/employee/tel/latereason/',//:checkid/:txt
	earlyreason:config.ServerIP+'/employee/tel/earlyreason/',//:checkid/:txt
	indentity:config.ServerIP+'/employee/get-employee-identity/',//:tel'
	underemployee:config.ServerIP+'/employee/get-underemployee-id/',//:identity'
	getemployByflag:config.ServerIP+'/employee/get-leaveovertime/',//:flag'
	//getleaveemployee:config.ServerIP+'/employee/get-leave/',//:tel'
	//getovertimeemployee:config.ServerIP+'/employee/get-overtime/',//:tel'
	getleaveemployee:config.ServerIP+'/employee/get-leave-auth/',//:tel'
	getovertimeemployee:config.ServerIP+'/employee/get-overtime-auth/',//:tel'
	getstatics:config.ServerIP+'/workcheck/getstatics-person/',	//获取某个人当月签到请假等信息//:year/:month/:employee_ref
	//请假相关
	newleave:config.ServerIP+'/leave/apply-leave',		//:employee_ref/:starttime/:endtime/:leavetype
	newgetleaveemployee:config.ServerIP+'/leave/new-get-leave-auth/',//:tel'
	approveleave:config.ServerIP+'/leave/new-verify-leave-approve/',		//:id
	refuseleave:config.ServerIP+'/leave/new-verify-leave-refuse/',		//:id
	getownleave:config.ServerIP+'/leave/get-own-leave/',		//employee_ref
	cancelleave:config.ServerIP+'/leave/cancel-leave/',			//:id
	cancelleaveafterverify: config.ServerIP+'/leave/cancel-leave-after-verify/',	//:id	//审核通过后的取消接口
	judgebusiness:config.ServerIP +'/leave/judge-business',

	//出差相关
	newbusiness:config.ServerIP+'/business/apply-business',		//:employee_ref/:starttime/:endtime/:businesstype
	newgetbusinessemployee:config.ServerIP+'/business/new-get-business-auth/',//:tel'
	approvebusiness:config.ServerIP+'/business/new-verify-business-approve/',		//:id
	refusebusiness:config.ServerIP+'/business/new-verify-business-refuse/',		//:id
	getownbusiness:config.ServerIP+'/business/get-own-business/',		//employee_ref
	cancelbusiness:config.ServerIP+'/business/cancel-business/',	//:id
	cancelbusinessafterverify: config.ServerIP+'/business/cancel-business-after-verify/',	//:id	//审核通过后的取消接口
	judgeleave:config.ServerIP +'/business/judge-leave',

	getownovertimework:config.ServerIP+'/workcheck/get-own-overtimework/',		//employee_ref
//	setapprovestate:config.ServerIP+'/workcheck/approve-refuse-leave-overtime/',//id/flag/state
	setapprovestate:config.ServerIP+'/workcheck/new-verify-overtime/',//id/state
	getcompany:config.ServerIP+'/system/company/getinfobyid/',	//:id
	//删除签退信息
	delcheckout:config.ServerIP+'/employee/tel/delcheckout/',	//employee_ref

	//日志相关
	worklogaddnew:config.ServerIP+'/worklog/addnew',//添加日志
	getworklogtext:config.ServerIP+'/worklog/getworklogtext',//查询
	delete:config.ServerIP+'/worklog/delete', //删除日志
	getjuniorstaffworklogbyid:config.ServerIP+'/worklog/get-junior-staff-worklog-byid/',//获取下属员工工作日志
	getunderingemployee:config.ServerIP+'/worklog/get-underling-employee/',//::id获取下属员工 get
	getworklogemployeedate:config.ServerIP+'/worklog/get-worklog-employee-date',//根据员工id数组和日期数组 返回工作日志 employeeArray dateArray为json格式字符串 post

	//项目进度管理
	scheduleaddnew:config.ServerIP+'/schedule/addnew', //添加新的项目任务
	// schedulegetinfobyid:config.ServerIP+'/schedule/getinfobyid/', //通过id查找项目任务信息
	schedulegetinfobyid:config.ServerIP+'/schedule/getinfobyid/', //通过id查找项目任务信息
	schedulegetinfobycreator:config.ServerIP+'/schedule/getinfobycreator/', //通过creator查找项目信息内容
	scheduledelete:config.ServerIP+'/schedule/delete/',//:id 删除任务
	schedulegetinfobysuptask:config.ServerIP+'/schedule/get-allsubtask-bysuptask/',//:id 查找子任务
	scheduleupdate:config.ServerIP+'/schedule/update/',//:id 修改
	schedulegetinfobyoperator:config.ServerIP+'/schedule/getinfobyoperator/',//:id 获取操作员字段中包含该员工的任务
	schedulegetinfobycharger:config.ServerIP+'/schedule/getinfobycharger/',//:charger获取指派员工名单
	scheduleeditschedule:config.ServerIP+'/schedule/edit-schedule/',//:taskid/:taskschedule修改进度，taskschedule（0-100）
	schedulegetallemployee:config.ServerIP+'/schedule/get-allemployee',//get 获得全部员工列表
	scheduleeditchargerarray:config.ServerIP+'/schedule/edit-chargerArray/',//:taskid指派人员 数组**(chargerArray)
	schedulegetemployeelist:config.ServerIP+'/schedule/get-employeelist/',//:taskid 获取员工列表**（new）
	scheduleaddsubtask:config.ServerIP+'/schedule/add-subtask',//添加子任务（回调）**
	scheduledelsubtask:config.ServerIP+'/schedule/del-subtask/',//删除子任务（回调）**
	scheduleneweditschedule:config.ServerIP+'/schedule/new-edit-schedule/',//修改进度new，taskschedule（0-100）** body:remarks
	schedulegettasklist:config.ServerIP+'/schedule/get-tasklist/',//:employeeid 获得任务列表 新(**)
	schedulegetinfobychargerarray:config.ServerIP+'/schedule/getinfobychargerarray',//获取chagerarray中的员工信息
	scheduleeditweight:config.ServerIP+'/schedule/edit-weight/',//:taskid/:taskweight修改权重（递归）**
	schedulegetallgeneraltask:config.ServerIP+'/schedule/get-allgeneraltask',// 获取所有总任务

	//公务用车管理
	bizvapply:config.ServerIP+'/bizvehicle/newapply',//公务用车申请
	bizvapplyInfo:config.ServerIP+'/bizvehicle/bizvapplyInfo/',//获取申请
	bizvapplycancel:config.ServerIP+'/bizvehicle/bizvapplycancel/',//取消未批准申请
	bizvapplyhide:config.ServerIP+'/bizvehicle/bizvapplyhide/',//对用户隐藏已处理的申请
	bizvapplyCheck:config.ServerIP+'/bizvehicle/bizvapplyCheck/',//审批申请
	bizvapplyIC:config.ServerIP+'/bizvehicle/getapplybycompany/',//分管人获取公司内的申请
	bizvehicleInfo:config.ServerIP+'/bizvehicle/getinfobycompany/',//获取一个公司下的车辆

	bizvrepair:config.ServerIP+'/bizvehicle/newrepair',//新建维修申请
	bizvrepairInfo:config.ServerIP+'/bizvehicle/bizvrepairInfo/',//获取申请
	bizvrepaircancel:config.ServerIP+'/bizvehicle/bizvrepaircancel/',//取消未批准申请
	bizvrepairCheck:config.ServerIP+'/bizvehicle/bizvrepairCheck/',//审批申请
	bizvrepairIC:config.ServerIP+'/bizvehicle/getrepairbycompany/',//分管人获取公司内的申请
	bizvjudge:config.ServerIP+'/bizvehicle/available',
	bizvend:config.ServerIP+'/bizvehicle/eventEndup/',
//wcp相关
	wcpwastestatic:config.ServerIP+'/wcpinterface/wastestatic-fordatatable',//获取月度统计表格
	wcpwastedailystatic:config.ServerIP+'/wcpinterface/wastestaticbydate-fordatatable',//获取日度统计表格

	isptempstatic:config.ServerIP + '/pdaispinterface/weektempstatic-fordatatable',//管网巡检温度统计表
	ispcompanylist:config4.ServerIP + '/company/getCompanyList',//管网巡检公司
	getCompanyPointsforMap:config4.ServerIP + '/inspection/getIspPoints/',//管网巡检公司
	getTempByDate:config4.ServerIP + '/weather/getTempByDate',
	getPointsContent:config4.ServerIP + '/inspection/getIspPointsContent/',
};
Date.prototype.Format = function (fmt) { //author: meizz
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}
function DateTimeConvert(datetime){
	var dt=Date.parse(datetime);
	//dt=dt-28800000;
	return new Date(dt);
}
function post(url,data,cb){
		api.ajax({
	           url:url,
	           cache:false,
	           method:'post',
	           timeout:5,
	           data:data
         },cb);
}
function get(url,cb){
	api.ajax({
		url:url,
		cache:false,
		method:'get',
		timeout:3
	},cb);
}
